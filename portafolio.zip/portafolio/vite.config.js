import { defineConfig } from 'vite';

export default defineConfig({
  // Si es necesario, puedes agregar más configuraciones aquí.
});

