import './styles/main.less';


document.addEventListener('DOMContentLoaded', () => {
    console.log('Portafolio cargado correctamente');
});